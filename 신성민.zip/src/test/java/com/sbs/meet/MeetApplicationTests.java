package com.sbs.meet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeetApplicationTests {

	@Test
	void contextLoads() {
	}

}
